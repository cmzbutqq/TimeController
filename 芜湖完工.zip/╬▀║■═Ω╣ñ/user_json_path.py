"""
这个文件用来存需要交互的user.json的路径
"""


user_json_path="C:/Users/Administrator/Desktop/TimeController-main/src/user.json"